/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda_vt.tienda.domain;

import jakarta.persistence.*;
import jakarta.persistence.Entity;
import java.io.Serializable;
import lombok.Data;
// para los get and setter sin necesidad de escribirlos

@Data
// va a gestionar una entidad de BD
@Entity
// nombre de la tabla de BD
@Table(name = "producto")
public class Producto implements Serializable {
    // llame primaria para decir que es eso.

    private static final long serialVersionUID = 1l;

    @Id
    // los valores se toman de la base de datos.
    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    Para referenciar el campo de java en BD
    @Column(name = "id_producto")
  
    private Long idProducto;
     //private Long idCategoria; nose utiliza mas por el @manytoone
    private String descripcion;
    private String detalle;
    private double precio;
    private int existencias;
    private String rutaImagen;
    private boolean activo;
    
     @ManyToOne
    @JoinColumn(name="id_categoria")
    private Categoria categoria;

}
