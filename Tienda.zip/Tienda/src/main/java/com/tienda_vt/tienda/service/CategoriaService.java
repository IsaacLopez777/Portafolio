package com.tienda_vt.tienda.service;

import com.tienda_vt.tienda.domain.Categoria;
import java.util.List;

public interface CategoriaService {
    
    //Se obtiene un listados de registro de la tabla Categoria en un arrayList 
    // de objetos categoria
    //Todos o solo los activos..
    public List<Categoria> getCategorias(boolean activos);
    
    public Categoria getCategoria(Categoria categoria);
    
    public void save(Categoria categoria);
    
    public void delete(Categoria categoria);
}
