/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda_vt.tienda.domain;

import jakarta.persistence.*;
import jakarta.persistence.Entity;
import java.io.Serializable;
import java.util.List;
import lombok.Data;
// para los get and setter sin necesidad de escribirlos

@Data
// va a gestionar una entidad de BD
@Entity
// nombre de la tabla de BD
@Table(name = "categoria")
public class Categoria implements Serializable {
    // llame primaria para decir que es eso.

    private static final long serialVersionUID = 1l;
    
    @Id
    // los valores se toman de la base de datos.
    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    Para referenciar el campo de java en BD
    @Column(name="id_categoria")
    
    private Long idCategoria;
    private String descripcion;
    private String rutaImagen;
    private boolean activo;
    
    @OneToMany
    @JoinColumn(name="id_categoria", updatable=false)
    private List<Producto> productos;

}
