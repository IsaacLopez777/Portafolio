package com.tienda_vt.tienda.services.impl;

import com.tienda_vt.tienda.dao.CategoriaDAO;
import com.tienda_vt.tienda.domain.Categoria;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.tienda_vt.tienda.service.CategoriaService;
// solamente una copia y estan atento a ser llamados.

@Service
public class CategoriaServiceImpl implements CategoriaService {
    //objeto categoria dao va hacer autoCreado
    // Va aver una copia en el servidor y se va a poder utilizar.

    @Autowired
    private CategoriaDAO categoriaDao;

    @Override
    public List<Categoria> getCategorias(boolean activos) {
        var lista = categoriaDao.findAll();

        if (activos) {
            // si solo quieros los activos
            lista.removeIf(c -> !c.isActivo());
            // lo recorre y lo llama temporalmente C 
//            si sale verdadero lo remueve
        }

        return lista;
    }

    @Override
    public Categoria getCategoria(Categoria categoria) {
        return categoriaDao.findById(categoria.getIdCategoria()).orElse(null);
    }

    @Override
    public void save(Categoria categoria) {
        categoriaDao.save(categoria);
    }

    @Override
    public void delete(Categoria categoria) {
        categoriaDao.delete(categoria);
    }

}
