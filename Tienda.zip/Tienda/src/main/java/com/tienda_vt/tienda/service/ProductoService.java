package com.tienda_vt.tienda.service;

import com.tienda_vt.tienda.domain.Producto;
import java.util.List;

public interface ProductoService {
    
    //Se obtiene un listados de registro de la tabla Producto en un arrayList 
    // de objetos producto
    //Todos o solo los activos..
    public List<Producto> getProductos(boolean activos);
    
    public Producto getProducto(Producto producto);
    
    public void save(Producto producto);
    
    public void delete(Producto producto);
    
    // Recupera una lista de productos basado en consulta ampliada.
    public List<Producto> consulta1(
            double precioInf, double precioSup);
    
      // Recupera una lista de productos basado en consulta JPQL.
    public List<Producto> consulta2(
            double precioInf, double precioSup);
    
  // Recupera una lista de productos basado en consulta SQL.
    public List<Producto> consulta3(
            double precioInf, double precioSup);    
    
}
