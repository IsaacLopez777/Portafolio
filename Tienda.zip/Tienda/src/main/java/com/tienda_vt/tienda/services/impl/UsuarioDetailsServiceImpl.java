/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda_vt.tienda.services.impl;

import com.tienda_vt.tienda.dao.UsuarioDao;
import com.tienda_vt.tienda.domain.Rol;
import com.tienda_vt.tienda.domain.Usuario;
import com.tienda_vt.tienda.service.UsuarioDetailsService;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("userDetailsService")
public class UsuarioDetailsServiceImpl
        implements UsuarioDetailsService, UserDetailsService {
    
    @Autowired
    private UsuarioDao usuarioDao;
    @Autowired
    private HttpSession session;

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {
        
        // se busca el usuario en la tabla de usuarios por medio del username
        Usuario usuario = usuarioDao.findByUsername(username);
        // se valida si se encontro el usuario con el username pasado...
        if (usuario == null) {
            // el usuario no se encontro
            throw new UsernameNotFoundException(username);
        }
        
        // si estamos aca entonces si se encontro el usuario:
        //Guardamos la imagen del usuario en una variable de session.
        
        session.removeAttribute("imagenUsuario");
        session.setAttribute("imagenUsuario", usuario.getRutaImagen());
        
        // se deben recuperar los roles del usuario y crear un arraylist con roles de seguridad.
        
        var roles = new ArrayList<GrantedAuthority>();
        // se revisan los roles del usuario y se convierten en roles de seguridad
        for(Rol r: usuario.getRoles()){
            roles.add(new SimpleGrantedAuthority(r.getNombre()));
            
        }
        // se retorna un usuario de Seguridad con roles incluidos.
        return new User(usuario.getUsername(),usuario.getPassword(),roles);
    }

}
