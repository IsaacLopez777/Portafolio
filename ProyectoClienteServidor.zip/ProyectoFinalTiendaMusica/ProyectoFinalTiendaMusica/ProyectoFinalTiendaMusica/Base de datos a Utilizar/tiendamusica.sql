-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 12-04-2024 a las 01:14:15
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tiendamusica`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `artista` varchar(20) NOT NULL,
  `genero` varchar(20) NOT NULL,
  `anioLanzamiento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id`, `codigo`, `nombre`, `precio`, `cantidad`, `artista`, `genero`, `anioLanzamiento`) VALUES
(1, '1275', 'Lady justice', 8500.00, 8, 'Metallica', 'rock', 1988),
(4, '5468', 'Silent Hill', 8000.00, 6, 'Akira Yamaoka', 'rock', 2005),
(5, '4682', 'Freezing Moon', 6000.00, 2, 'Mayhem', 'rock', 1988),
(6, '8574', 'Bohemian Rhapsody', 15000.00, 45, 'Queen', 'rock', 1987),
(7, '7385', 'Thriller', 12000.00, 15, 'Michael Jackson', 'pop', 1995),
(8, '3281', 'Cuphead', 4600.00, 13, 'Kristofer Maddigan', 'Jazz', 2017),
(9, '8456', 'Tocatta in D Minor', 2600.00, 2, 'Johann Sebastian', 'Clasica', 1845),
(10, '7569', 'Filosofem', 9650.00, 8, 'Burzum', 'Metal', 1994),
(11, '7528', 'Dont\'you forget me', 7800.00, 9, 'Simple Minds', 'rock', 1985);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
