package Modelo;

import java.sql.*;

public class ConexionBD {
    Connection con = null;
    
    String base = "tiendamusica"; //Nombre de la base de datos
    String url = "jdbc:mysql://localhost:3306/" + base; //Dirección, puerto y nombre de la Base de Datos
    String user = "root"; //Usuario de Acceso a MySQL
    String password = ""; //Password del usuario
    
    public Connection getConexion() {
        try {
            Class.forName("com.mysql.jdbc.Connection");
            con = DriverManager.getConnection(url, user, password);
        } catch(ClassNotFoundException | SQLException e) {
            System.err.println(e);
        }
        return con;
    }
}