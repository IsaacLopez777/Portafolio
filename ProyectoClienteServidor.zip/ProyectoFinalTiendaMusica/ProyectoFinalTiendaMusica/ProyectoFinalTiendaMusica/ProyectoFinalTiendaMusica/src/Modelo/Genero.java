package Modelo;

// Clase enumerada para manejar las opciones del genero de música
public enum Genero {
    rock,
    pop,
    Jazz,
    Metal,
    Clasica
}
