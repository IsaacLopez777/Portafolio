package Modelo;

import java.sql.*;
import java.util.ArrayList;

//Clase que se usará para añadir las funciones a la Base de Datos
public class ConsultasBD extends ConexionBD {

    public boolean insertarCD(int codigo, String nombre, double precio, int cantidad, String artista, Genero genero, int año) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "INSERT INTO producto(codigo, nombre, precio, cantidad, artista, genero, anioLanzamiento) VALUES (?,?,?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, codigo);
            ps.setString(2, nombre);
            ps.setDouble(3, precio);
            ps.setInt(4, cantidad);
            ps.setString(5, artista);
            ps.setString(6, genero.toString());
            ps.setInt(7, año);

            // Se ejecuta la consulta
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                // Se cierra la conexión
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean actualizarCD(int codigo, String nombre, double precio, int cantidad, String artista, 
            Genero genero, int año, int id) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "UPDATE producto SET codigo=?, nombre=?, precio=?, cantidad=?, artista=?, genero=?, anioLanzamiento=? WHERE id=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, codigo);
            ps.setString(2, nombre);
            ps.setDouble(3, precio);
            ps.setInt(4, cantidad);
            ps.setString(5, artista);
            ps.setString(6, genero.toString());
            ps.setInt(7, año);
            ps.setInt(8, id);

            //Se ejecuta la consulta
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                // Se cierra la conexión
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean eliminarCD(int id) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "DELETE FROM producto WHERE id=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            //Sirve para que ejecute la eliminación de datos
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                // Se cierra la conexión
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public ArrayList<CD> consultar() {
        ArrayList<CD> cds = new ArrayList<>();
        PreparedStatement ps = null;
        Connection con = getConexion();
        ResultSet rs = null;

        String sql = "SELECT * FROM producto";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id"); 
                int codigo = rs.getInt("codigo");
                String nombre = rs.getString("nombre");
                double precio = rs.getDouble("precio");
                int cantidad = rs.getInt("cantidad");
                String artista = rs.getString("artista");
                String generoStr = rs.getString("genero");
                Genero genero = Genero.valueOf(generoStr);
                int año = rs.getInt("anioLanzamiento");

                CD cd = new CD(id, codigo, nombre, precio, cantidad, artista, genero, año);
                cds.add(cd);
            }
        } catch (SQLException e) {
            System.err.println(e);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
        return cds;
    }
}
