package Modelo;

public class CD extends Producto {
    // Atributos
    private String artista;
    private Genero genero;
    private int añoLanzamiento;

    // Constructor lleno
    public CD(int id, int codigo, String nombre, double precio, int cantidad, String artista, Genero genero, int añoLanzamiento) {
        super(id, codigo, nombre, precio, cantidad);
        this.artista = artista;
        this.genero = genero;
        this.añoLanzamiento = añoLanzamiento;
    }

    // Getters y Setters
    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    public int getAñoLanzamiento() {
        return añoLanzamiento;
    }

    public void setAñoLanzamiento(int añoLanzamiento) {
        this.añoLanzamiento = añoLanzamiento;
    }
}
