/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import javax.swing.JOptionPane;

/**
 *
 * @author Raquel
 */
public class Usuario {

    private String usuario;
    private String contrasena;

    public Usuario() {
        this.usuario = "Lopez";
        this.contrasena = "123";
    }

    public Usuario(String usuario, String contrasena) {
        this.usuario = usuario;
        this.contrasena = contrasena;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public boolean verificar(String usuarioIngresado, String contrasenaIngresada) {
        try {
            if (usuarioIngresado.isEmpty() || contrasenaIngresada.isEmpty()) {
                throw new NullPointerException("Error, los campos no pueden estar vacíos."); 
            } else if (this.usuario.equals(usuarioIngresado) && this.contrasena.equals(contrasenaIngresada)) {
                return true;
            } else {
                JOptionPane.showMessageDialog(null, 
                        "Nombre de usuario o contraseña incorrectos. Inténtelo de nuevo.", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}
