package GUI;

public class Principal {

    public static void main(String[] args) {
        // TODO code application logic here
        Inicio inicio = new Inicio();
    }
    
}
