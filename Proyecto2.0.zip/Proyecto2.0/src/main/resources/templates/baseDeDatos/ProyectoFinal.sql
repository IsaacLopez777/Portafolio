-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS zapatodeluxe;
drop user if exists usuario_prueba;


USE zapatodeluxe;

-- Se crea un usuario para la base de datos llamado "usuario_prueba" con la contraseña "Usuario_Clave."
CREATE USER 'usuario_prueba'@'%' IDENTIFIED BY 'Usuar1o_Clave.';

-- Se asignan los privilegios sobre la base de datos zapatodeluxe al usuario creado
GRANT ALL PRIVILEGES ON zapatodeluxe.* TO 'usuario_prueba'@'%';
FLUSH PRIVILEGES;

-- Crear la tabla de categorías
CREATE TABLE categoria (
  id_categoria INT NOT NULL AUTO_INCREMENT,
  descripcion VARCHAR(50),
  ruta_imagen VARCHAR(1024),
  activo BOOL,
  PRIMARY KEY (id_categoria)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crear la tabla de productos
CREATE TABLE producto (
  id_producto INT NOT NULL AUTO_INCREMENT,
  id_categoria INT NOT NULL,
  descripcion VARCHAR(50),
  detalle VARCHAR(255),
  precio DOUBLE,
  existencias INT,
  ruta_imagen VARCHAR(1024),
  activo BOOL,
  PRIMARY KEY (id_producto),
  FOREIGN KEY (id_categoria) REFERENCES categoria(id_categoria)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crear la tabla de usuarios
CREATE TABLE usuario (
  id_usuario INT NOT NULL AUTO_INCREMENT,
  username VARCHAR(20) NOT NULL,
  password VARCHAR(512) NOT NULL,
  nombre VARCHAR(20) NOT NULL,
  apellidos VARCHAR(30) NOT NULL,
  correo VARCHAR(25),
  telefono VARCHAR(15),
  ruta_imagen VARCHAR(1024),
  activo BOOL,
  PRIMARY KEY (id_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crear la tabla de facturas
CREATE TABLE factura (
  id_factura INT NOT NULL AUTO_INCREMENT,
  id_usuario INT NOT NULL,
  fecha DATE,
  total DOUBLE,
  estado INT,
  PRIMARY KEY (id_factura),
  FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crear la tabla de ventas
CREATE TABLE venta (
  id_venta INT NOT NULL AUTO_INCREMENT,
  id_factura INT NOT NULL,
  id_producto INT NOT NULL,
  precio DOUBLE,
  cantidad INT,
  PRIMARY KEY (id_venta),
  FOREIGN KEY (id_factura) REFERENCES factura(id_factura),
  FOREIGN KEY (id_producto) REFERENCES producto(id_producto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crear la tabla de roles
CREATE TABLE rol (
  id_rol INT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(20),
  id_usuario INT,
  PRIMARY KEY (id_rol),
  FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crear la tabla de ubicaciones
CREATE TABLE ubicacion (
  id_ubicacion INT NOT NULL AUTO_INCREMENT,
  ciudad VARCHAR(50) NOT NULL,
  direccion VARCHAR(255) NOT NULL,
  horario_inicio TIME NOT NULL,
  horario_fin TIME NOT NULL,
  imagen_url VARCHAR(1024),
  activo BOOL DEFAULT TRUE,
  PRIMARY KEY (id_ubicacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insertar datos en la tabla de usuarios
INSERT INTO usuario (id_usuario, username, password, nombre, apellidos, correo, telefono, ruta_imagen, activo) VALUES 
(1, 'juan', '$2a$10$P1.w58XvnaYQUQgZUCk4aO/RTRl8EValluCqB3S2VMLTbRt.tlre.', 'Juan', 'Castro Mora', 'jcastro@gmail.com', '4556-8978', 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Juan_Diego_Madrigal.jpg/250px-Juan_Diego_Madrigal.jpg', TRUE),
(2, 'rebeca', '$2a$10$GkEj.ZzmQa/aEfDmtLIh3udIH5fMphx/35d0EYeqZL5uzgCJ0lQRi', 'Rebeca', 'Contreras Mora', 'acontreras@gmail.com', '5456-8789', 'https://upload.wikimedia.org/wikipedia/commons/0/06/Photo_of_Rebeca_Arthur.jpg', TRUE),
(3, 'pedro', '$2a$10$koGR7eS22Pv5KdaVJKDcge04ZB53iMiw76.UjHPY.XyVYlYqXnPbO', 'Pedro', 'Mena Loria', 'lmena@gmail.com', '7898-8936', 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Eduardo_de_Pedro_2019.jpg/480px-Eduardo_de_Pedro_2019.jpg?20200109230854', TRUE),
(4, 'isaac', '$2a$10$P1.w58XvnaYQUQgZUCk4aO/RTRl8EValluCqB3S2VMLTbRt.tlre.', 'Isaac', 'Lopez', 'lopez@gmail.com', '87425031', NULL, TRUE),
(5, 'nahomi', '$2a$10$GkEj.ZzmQa/aEfDmtLIh3udIH5fMphx/35d0EYeqZL5uzgCJ0lQRi', 'Nahomi', 'Varela', 'nalvarez89013@ufide.ac.cr', '84199641', NULL, TRUE),
(6, 'brandon', '$2a$10$koGR7eS22Pv5KdaVJKDcge04ZB53iMiw76.UjHPY.XyVYlYqXnPbO', 'Brandon', 'Madrigal', 'bquiros50428@ufide.ac.cr', '86279383', NULL, TRUE),
(7, 'dylan', '$2a$10$P1.w58XvnaYQUQgZUCk4aO/RTRl8EValluCqB3S2VMLTbRt.tlre.', 'Dylan', 'Zamora', 'dsolano40819@ufide.ac.cr', '63325043', NULL, TRUE);

-- Insertar datos en la tabla de categorías
INSERT INTO categoria (descripcion, ruta_imagen, activo) VALUES 
('Tenis Nike', 'https://example.com/nike.jpg', TRUE),
('Tenis Puma', 'https://example.com/puma.jpg', TRUE),
('Tenis Adidas', 'https://example.com/adidas.jpg', TRUE),
('Botas Timberland', 'https://example.com/timberland.jpg', TRUE);

-- Insertar datos en la tabla de productos
INSERT INTO producto (id_categoria, descripcion, detalle, precio, existencias, ruta_imagen, activo) VALUES
(1, 'Nike Air Max', 'Comodidad y estilo', 100.00, 50, 'https://static.nike.com/a/images/t_PDP_936_v1/f_auto,q_auto:eco/lx0owmisj943sr59emb8/AIR+MAX+PLUS.png', TRUE),
(1, 'Nike Revolution', 'Diseño moderno', 80.00, 30, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1NRQp4L1Me4AbtoTXiXNyvH2VDALJVy_JRg&s', TRUE),
(2, 'Puma Suede', 'Clásico de Puma', 70.00, 40, 'https://www.unimart.com/cdn/shop/products/8-4_1_d69b2d6b-a6b6-4fe9-bc45-f36d73c0907f.jpg?v=1671137200', TRUE),
(2, 'Puma Smash', 'Elegancia y confort', 60.00, 20, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgFDLzhPXIWiPr3VYaw-HE5AermyYZFeNV0Q&s', TRUE),
(3, 'Adidas Superstar', 'Icónicos y cómodos', 90.00, 35, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDr591DmW3XQ43itTGZkS5rLG-bmuoHX2ohA&s', TRUE),
(3, 'Adidas Ultraboost', 'Rendimiento superior', 120.00, 25, 'https://images.stockx.com/images/adidas-Ultra-Boost-40-DNA-White-Green-Product.jpg?fit=fill&bg=FFFFFF&w=1200&h=857&auto=compress&dpr=2&trim=color&updated_at=1686036356&fm=webp&q=60', TRUE),
(4, 'Timberland Classic', 'Resistentes y duraderos', 150.00, 15, 'https://cdn11.bigcommerce.com/s-s62r70/images/stencil/1280x1280/products/3129/6136/10860-713-timberland-wheat-nubuck-toddler-work-boot__27712.1601744638.jpg?c=2', TRUE),
(4, 'Timberland Premium', 'Calidad y estilo', 170.00, 10, 'https://m.media-amazon.com/images/I/81MfDAp9umL._AC_SL1500_.jpg', TRUE);

-- Insertar datos en la tabla de facturas
INSERT INTO factura (id_usuario, fecha, total, estado) VALUES
(1, '2024-01-05', 300.00, 2),
(2, '2024-01-07', 450.00, 2),
(3, '2024-01-07', 500.00, 2),
(4, '2024-01-15', 200.00, 1),
(5, '2024-01-17', 350.00, 1),
(6, '2024-01-21', 400.00, 1);

-- Insertar datos en la tabla de ventas
INSERT INTO venta (id_factura, id_producto, precio, cantidad) VALUES
(1, 1, 100.00, 2),
(1, 3, 70.00, 2),
(2, 2, 80.00, 1),
(2, 5, 90.00, 3),
(3, 4, 60.00, 2),
(3, 7, 150.00, 1),
(4, 6, 120.00, 2),
(4, 8, 170.00, 1),
(5, 1, 100.00, 3),
(5, 5, 90.00, 1),
(6, 3, 70.00, 2),
(6, 7, 150.00, 1);

-- Insertar datos en la tabla de ubicaciones
INSERT INTO ubicacion (ciudad, direccion, horario_inicio, horario_fin, imagen_url, activo) VALUES 
('Cartago', 'Mall Paseo Metrópoli', '08:00:00', '22:00:00', 'https://example.com/images/cartago-map.png', TRUE),
('San José', 'Mall San Pedro', '08:00:00', '22:00:00', 'https://example.com/images/sanjose-map.png', TRUE),
('Heredia', 'Centro Comercial Oxígeno', '08:00:00', '22:00:00', 'https://example.com/images/heredia-map.png', TRUE);

-- Insertar datos en la tabla de roles
INSERT INTO rol (nombre, id_usuario) VALUES 
('ROLE_USER', (SELECT id_usuario FROM usuario WHERE username = 'juan')),
('ROLE_VENDEDOR', (SELECT id_usuario FROM usuario WHERE username = 'juan')),
('ROLE_ADMIN', (SELECT id_usuario FROM usuario WHERE username = 'juan'));

INSERT INTO rol (nombre, id_usuario) VALUES 
('ROLE_USER', (SELECT id_usuario FROM usuario WHERE username = 'rebeca')),
('ROLE_VENDEDOR', (SELECT id_usuario FROM usuario WHERE username = 'rebeca'));

INSERT INTO rol (nombre, id_usuario) VALUES 
('ROLE_USER', (SELECT id_usuario FROM usuario WHERE username = 'pedro'));

INSERT INTO rol (nombre, id_usuario) VALUES 
('ROLE_USER', (SELECT id_usuario FROM usuario WHERE username = 'isaac')),
('ROLE_VENDEDOR', (SELECT id_usuario FROM usuario WHERE username = 'isaac')),
('ROLE_ADMIN', (SELECT id_usuario FROM usuario WHERE username = 'isaac'));

INSERT INTO rol (nombre, id_usuario) VALUES 
('ROLE_USER', (SELECT id_usuario FROM usuario WHERE username = 'nahomi')),
('ROLE_VENDEDOR', (SELECT id_usuario FROM usuario WHERE username = 'nahomi')),
('ROLE_ADMIN', (SELECT id_usuario FROM usuario WHERE username = 'nahomi'));

INSERT INTO rol (nombre, id_usuario) VALUES 
('ROLE_USER', (SELECT id_usuario FROM usuario WHERE username = 'brandon')),
('ROLE_VENDEDOR', (SELECT id_usuario FROM usuario WHERE username = 'brandon')),
('ROLE_ADMIN', (SELECT id_usuario FROM usuario WHERE username = 'brandon'));

INSERT INTO rol (nombre, id_usuario) VALUES 
('ROLE_USER', (SELECT id_usuario FROM usuario WHERE username = 'dylan')),
('ROLE_VENDEDOR', (SELECT id_usuario FROM usuario WHERE username = 'dylan')),
('ROLE_ADMIN', (SELECT id_usuario FROM usuario WHERE username = 'dylan'));
