package ProyectoDesarrollo.Proyecto.controller;

import ProyectoDesarrollo.Proyecto.service.UbicacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Controlador para gestionar la vista de "Conózcanos".
 */
@Controller
@RequestMapping("/conozcanos")
public class ConozcanosController {

    @Autowired
    private UbicacionService ubicacionService; 

 
    @GetMapping
    public String listado(Model model) {
        var ubicaciones = ubicacionService.getUbicaciones(true);

        model.addAttribute("ubicaciones", ubicaciones);

        return "conozcanos/listado";
    }
}
