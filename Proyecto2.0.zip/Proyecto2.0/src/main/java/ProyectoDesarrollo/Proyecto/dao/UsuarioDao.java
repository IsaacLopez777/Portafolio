/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ProyectoDesarrollo.Proyecto.dao;

import ProyectoDesarrollo.Proyecto.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author lopez
 */
public interface UsuarioDao extends JpaRepository<Usuario, Long> {
// esto funciona para recibir un username y devolver un usuario de manera directa.

    public Usuario findByUsername(String username);

    // funciones ampliadas.
    public Usuario findByUsernameAndPassword(String username, String Password);

    public Usuario findByUsernameOrCorreo(String username, String correo);

    public boolean existsByUsernameOrCorreo(String username, String correo);

}
