/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ProyectoDesarrollo.Proyecto.dao;

import ProyectoDesarrollo.Proyecto.domain.Producto;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author lopez
 */
public interface ProductoDao extends JpaRepository<Producto, Long> {

    @Query(nativeQuery = true,
            value = "SELECT * FROM producto WHERE descripcion LIKE %:keyword% ORDER BY descripcion ASC")
    List<Producto> encontrarPorPalabra(@Param("keyword") String keyword);
}
