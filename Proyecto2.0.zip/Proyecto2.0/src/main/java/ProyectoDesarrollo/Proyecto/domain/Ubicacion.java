package ProyectoDesarrollo.Proyecto.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import lombok.Data;

@Data
@Entity
@Table(name="ubicacion")
public class Ubicacion implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ubicacion")
    private Long idUbicacion;

    @Column(name = "ciudad") 
    private String ciudad;

    private String direccion;

    @Column(name = "horario_inicio")
    private String horarioInicio;

    @Column(name = "horario_fin")
    private String horarioFin;

    @Column(name = "imagen_url")
    private String imagenUrl;

    private boolean activo;
}
