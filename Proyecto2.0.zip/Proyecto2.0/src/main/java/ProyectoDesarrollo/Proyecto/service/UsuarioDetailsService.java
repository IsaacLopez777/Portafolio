/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ProyectoDesarrollo.Proyecto.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

/**
 *
 * @author lopez
 */
public interface UsuarioDetailsService {

    // metodo para buscar un usuario por el username podria ser que no lo encuentre pero si lo encuentra devuelve un objeto userDetails
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException;
}
