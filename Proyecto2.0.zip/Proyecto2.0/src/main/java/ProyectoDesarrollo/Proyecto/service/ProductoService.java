/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ProyectoDesarrollo.Proyecto.service;

import ProyectoDesarrollo.Proyecto.domain.Producto;
import java.util.List;

/**
 *
 * @author lopez
 */
public interface ProductoService {

    //Se obtiene un listados de registro de la tabla Producto en un arrayList 
    // de objetos producto
    //Todos o solo los activos..
    public List<Producto> getProductos(boolean activos);

    public Producto getProducto(Producto producto);

    public void save(Producto producto);

    public void delete(Producto producto);

    List<Producto> encontrarPorPalabra(String keyword);

}
