/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoDesarrollo.Proyecto.service.impl;

import ProyectoDesarrollo.Proyecto.dao.ProductoDao;
import ProyectoDesarrollo.Proyecto.domain.Producto;
import ProyectoDesarrollo.Proyecto.service.ProductoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductoServiceImpl implements ProductoService {
    //objeto producto dao va hacer autoCreado
    // Va aver una copia en el servidor y se va a poder utilizar.

    @Autowired
    private ProductoDao productoDao;

    @Override
    public List<Producto> getProductos(boolean activos) {
        var lista = productoDao.findAll();

        if (activos) {
            // si solo quieros los activos
            lista.removeIf(c -> !c.isActivo());
            // lo recorre y lo llama temporalmente C 
//            si sale verdadero lo remueve
        }

        return lista;
    }

    @Override
    public Producto getProducto(Producto producto) {
        return productoDao.findById(producto.getIdProducto()).orElse(null);
    }

    @Override
    public void save(Producto producto) {
        productoDao.save(producto);
    }

    @Override
    public void delete(Producto producto) {
        productoDao.delete(producto);
    }

    @Override
    public List<Producto> encontrarPorPalabra(String keyword) {
        return productoDao.encontrarPorPalabra(keyword);
    }

   
}
