/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoDesarrollo.Proyecto.service.impl;

import ProyectoDesarrollo.Proyecto.dao.UbicacionDao;
import ProyectoDesarrollo.Proyecto.domain.Ubicacion;
import ProyectoDesarrollo.Proyecto.service.UbicacionService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UbicacionServiceImpl implements UbicacionService {

    @Autowired
    private UbicacionDao ubicacionDao;


    @Override
    public List<Ubicacion> getUbicaciones(boolean activos) {
        var lista = ubicacionDao.findAll();

        if (activos) {
            lista.removeIf(ubicacion -> !ubicacion.isActivo());
  
        }

        return lista;
    }

    @Override
    public Ubicacion getUbicacion(Ubicacion ubicacion) {
        return ubicacionDao.findById(ubicacion.getIdUbicacion()).orElse(null);
    }

    @Override
    public void save(Ubicacion ubicacion) {
        ubicacionDao.save(ubicacion);
    }

    @Override
    public void delete(Ubicacion ubicacion) {
        ubicacionDao.delete(ubicacion);
    }
}
