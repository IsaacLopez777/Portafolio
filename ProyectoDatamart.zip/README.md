# DataWarehouse
Proyecto sql DataWarehouse

By
Nicole Portuguez Barboza,
Jimena Zarate Pérez,
Kristel Sofía Sancho Herrera,
Isaac Josué Tenorio López.
