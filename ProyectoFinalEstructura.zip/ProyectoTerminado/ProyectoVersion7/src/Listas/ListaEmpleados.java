package Listas;

import Colas.ColasVacaciones;
import Datos.Empleado;
import Datos.Persona;
import javax.swing.JOptionPane;

public class ListaEmpleados {
    // lista enlazadas simples.

    private NodoEmpleado inicio;
    private int contadorID;

    public ListaEmpleados() {
        this.inicio = null;
        this.contadorID = 1;
    }

    public boolean vacia() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

    public void agregar() {
        Empleado empleado = new Empleado();

        try {
            String nombre = JOptionPane.showInputDialog("Dijite el nombre");
            int cedula = Integer.parseInt(JOptionPane.showInputDialog("Dijite el numero de cedula: "));
            int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad"));

            empleado.setDatosPersonales(new Persona(nombre, cedula, edad));

            empleado.setDepartemento(JOptionPane.showInputDialog("Ingrese el departamento"));
            empleado.setIdEmpleado(contadorID++);
            empleado.setSalario(Double.parseDouble(JOptionPane.showInputDialog("Dijite el salario del empleado: ")));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los datos deben ser numericos");
        }

        NodoEmpleado nuevo = new NodoEmpleado();
        nuevo.setDato(empleado);

        if (vacia()) {
            inicio = nuevo;
        } else if (empleado.getIdEmpleado() < inicio.getDato().getIdEmpleado()) {
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
        } else if (inicio.getSiguiente() == null) {

            inicio.setSiguiente(nuevo);
        } else {
            NodoEmpleado aux = inicio;
            // mientras el dato siguiente no este nulo
            // y el dato a insetar sea mayor que el de la lista
            // apunta al siguiente.
            while (aux.getSiguiente() != null && aux.getSiguiente().getDato().getIdEmpleado() < empleado.getIdEmpleado()) {
                aux = aux.getSiguiente();
            }

            nuevo.setSiguiente(aux.getSiguiente());
            /// insertamos e el medio.
            aux.setSiguiente(nuevo);
        }
    }

    public void eliminar() {
        if (vacia()) {
            JOptionPane.showMessageDialog(null, "No hay empleados en la lista.");
            return;
        }
        int idEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del empleado a eliminar:"));
        NodoEmpleado actual = inicio;
        NodoEmpleado anterior = null;
        while (actual != null && actual.getDato().getIdEmpleado() != idEliminar) {
            anterior = actual;
            actual = actual.getSiguiente();
        }
        if (actual == null) {
            JOptionPane.showMessageDialog(null, "El id ingresado no se encontro!");
            return;
        }
        if (anterior == null) {
            inicio = inicio.getSiguiente();
        } else {
            anterior.setSiguiente(actual.getSiguiente());
        }
        JOptionPane.showMessageDialog(null, "Empleado con ID " + idEliminar + " eliminado correctamente.");
    }

    public void mostrar() {
        if (!vacia()) {
            String s = "";
            NodoEmpleado aux = inicio;
            while (aux != null) {
                s += "Id " + aux.getDato().getIdEmpleado() + "\nNombre:" + aux.getDato().getDatosPersonales().getNombre() + "\nCedula: " + aux.getDato().getDatosPersonales().getCedula()
                        + "\nEdad: " + aux.getDato().getDatosPersonales().getEdad() + "\nDepartamento: " + aux.getDato().getDepartemento()
                        + "\nSalario: " + aux.getDato().getSalario() + "\n\n";
                aux = aux.getSiguiente();
            }
            JOptionPane.showMessageDialog(null, "Lista de empleados registrados\n" + s + "\n\n");
        } else {
            JOptionPane.showMessageDialog(null, "No hay empleados registrados.");
        }
    }

    public void modificar() {
        if (!vacia()) {
            int idModificar = Integer.parseInt(JOptionPane.showInputDialog("Dijite el Id a actualizar: "));
            NodoEmpleado nuevoActual = inicio;
            while (nuevoActual != null && nuevoActual.getDato().getIdEmpleado() != idModificar) {
                nuevoActual = nuevoActual.getSiguiente();
            }
            if (nuevoActual == null) {
                JOptionPane.showMessageDialog(null, "Empleado con el id : " + idModificar + " no se encontro.");
                return;
            }
            String nuevoNom = JOptionPane.showInputDialog("Dijite el nuevo nombre:");
            int Ncedula = Integer.parseInt(JOptionPane.showInputDialog("Dijite la nueva cedula: "));
            int Nedad = Integer.parseInt(JOptionPane.showInputDialog("Dijite la edad: "));
            String Ndpartamento = JOptionPane.showInputDialog("Dijite el departamento: ");
            Double salario = Double.parseDouble(JOptionPane.showInputDialog("Dijite el nuevo salario del empleado: "));

            nuevoActual.getDato().getDatosPersonales().setNombre(nuevoNom);
            nuevoActual.getDato().getDatosPersonales().setCedula(Ncedula);
            nuevoActual.getDato().getDatosPersonales().setEdad(Nedad);
            nuevoActual.getDato().setDepartemento(Ndpartamento);
            nuevoActual.getDato().setSalario(salario);

            JOptionPane.showMessageDialog(null, "Empleado Id:" + idModificar + " actualizado correctamente.");

        } else {
            JOptionPane.showMessageDialog(null, "No hay empleados registrados.");
        }
    }

    public NodoEmpleado getInicio() {
        return inicio;
    }
}
