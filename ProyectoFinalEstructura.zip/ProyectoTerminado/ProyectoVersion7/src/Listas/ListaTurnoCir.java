/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Listas;

import Datos.Turno;
import javax.swing.JOptionPane;

/**
 *
 * @author lopez
 */
public class ListaTurnoCir {

    // lista circular para turnos 
// lista simple circular    
    private NodoTurno inicio;
    private NodoTurno fin;

    public ListaTurnoCir() {
        this.inicio = null;
        this.fin = null;
    }

    public boolean vacia() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

    public void agregarTurno(int idEmpleado, ListaEmpleados listaEmpleados) {
        if (listaEmpleados.vacia()) {
            JOptionPane.showMessageDialog(null, "No hay empleados para asignar los turnos.");
            return;
        }
        NodoEmpleado aux = listaEmpleados.getInicio();
        boolean encontrado = false;

        while (aux != null) {
            if (aux.getDato().getIdEmpleado() == idEmpleado) {
                Turno turnos = new Turno();
                turnos.setHoraEntrada(Double.parseDouble(JOptionPane.showInputDialog("Dijite la hora de entrada: ")));
                turnos.setHoraSalida(Double.parseDouble(JOptionPane.showInputDialog("Dijite la hora de salida:")));

                NodoTurno nuevo = new NodoTurno();
                nuevo.setDato(turnos);
                nuevo.setEmpleado(aux.getDato());

                if (vacia()) {
                    inicio = nuevo;
                    fin = nuevo;
                    fin.setSiguiente(inicio);
                } else if (turnos.getHoraEntrada() < inicio.getDato().getHoraSalida()) {
                    nuevo.setSiguiente(inicio);
                    inicio = nuevo;
                    fin.setSiguiente(inicio);
                } else if (turnos.getHoraEntrada() >= fin.getDato().getHoraEntrada()) {
                    fin.setSiguiente(nuevo);
                    nuevo.setSiguiente(inicio);
                    fin = nuevo;

                } else {
                    NodoTurno auxTurnos = inicio;
                    while (auxTurnos.getSiguiente().getDato().getHoraEntrada() < turnos.getHoraEntrada()) {
                        aux = aux.getSiguiente();
                    }
                    nuevo.setSiguiente(auxTurnos.getSiguiente());
                    auxTurnos.setSiguiente(nuevo);
                }
                encontrado = true;
                JOptionPane.showMessageDialog(null, "Turno agregado con exito.");
                break;
            }
            aux = aux.getSiguiente();
        }
        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "Nose encontro el id ingresado");
        }

    }

    public void extraer() {
        if (!vacia()) {
            inicio = inicio.getSiguiente();
            fin.setSiguiente(inicio);
            JOptionPane.showMessageDialog(null, "Elemento extraido");
        } else {
            JOptionPane.showMessageDialog(null, "Lista vacia.");

        }
    }

    public void mostrar() {
        if (!vacia()) {
            String s = "";
            NodoTurno aux = inicio;
            do {
                String horaEntrada = convertirHoraMilitar(aux.getDato().getHoraEntrada());
                String horaSalida = convertirHoraMilitar(aux.getDato().getHoraSalida());

                s += "Id del empleado: " + aux.getEmpleado().getIdEmpleado() + "\n"
                        + "Nombre del empleado: " + aux.getEmpleado().getDatosPersonales().getNombre() + "\n"
                        + "Hora de entrada: " + horaEntrada + "\n" + "Hora de salida: " + horaSalida + "\n\n";
                aux = aux.getSiguiente();
            } while (aux != inicio);
            JOptionPane.showMessageDialog(null, "Lista de turnos:\n" + s);
        } else {
            JOptionPane.showMessageDialog(null, "No hay turnos registrados.");
        }
    }

    private String convertirHoraMilitar(double hora) {
        // convertimos la hora en un valor entero para obtener valor puntual.
        // 9.4 hora 9:..
        int horas = (int) hora;

        int minutos = (int) ((hora - horas) * 60);
        String formatoAmpm = String.format("%02d:%02d", horas, minutos);
// condiciones en militar para am y pm.
        if (horas >= 0 && horas < 12) {
            return formatoAmpm + " AM";
        } else {
            return formatoAmpm + " PM";
        }
    }

    public void modificarTurnos(int idEmpleado, ListaEmpleados lista) {
        NodoTurno aux = inicio;

        while (aux != null) {
            if (aux.getEmpleado().getIdEmpleado() == idEmpleado) {
                double nuevaHoraE = Double.parseDouble(JOptionPane.showInputDialog("Dijite la nueva hora de entrada: "));
                double nuevaHoraS = Double.parseDouble(JOptionPane.showInputDialog("Dijite la nueva hora de salida: "));

                aux.getDato().setHoraEntrada(nuevaHoraE);
                aux.getDato().setHoraSalida(nuevaHoraS);
                JOptionPane.showMessageDialog(null, "Turno modificado con exito.");
                break;
            }
            aux = aux.getSiguiente();
        }
    }
}
