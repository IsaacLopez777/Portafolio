/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Listas;

import Datos.Empleado;
import Datos.Turno;

/**
 *
 * @author lopez
 */
public class NodoTurno {

    // lista circular.
    private NodoTurno siguiente;
    private Turno dato;
    private Empleado empleado;

    public NodoTurno() {
        this.siguiente = null;
    }

    public NodoTurno getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoTurno siguiente) {
        this.siguiente = siguiente;
    }

    public Turno getDato() {
        return dato;
    }

    public void setDato(Turno dato) {
        this.dato = dato;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

}
