/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Listas;

import Datos.Empleado;

/**
 *
 * @author lopez
 */
public class NodoEmpleado {
    // nodo lista enlazadas simples:
    
    private Empleado dato;
    private NodoEmpleado siguiente;
    
    public NodoEmpleado(){
        this.siguiente = null;
    }

    public Empleado getDato() {
        return dato;
    }

    public void setDato(Empleado dato) {
        this.dato = dato;
    }

    public NodoEmpleado getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoEmpleado siguiente) {
        this.siguiente = siguiente;
    }
    
    
    
    
}
