/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

/**
 *
 * @author lopez
 */
public class Empleado {

    private Persona datosPersonales;
    private int idEmpleado;
    private String departemento;
    private double salario;

    public Empleado(Persona datosPersonales, int idEmpleado, String departemento, double salario) {
        this.datosPersonales = datosPersonales;
        this.idEmpleado = idEmpleado;
        this.departemento = departemento;
        this.salario = salario;
    }
    
    public Empleado(){
          this.datosPersonales = datosPersonales;
        this.idEmpleado = idEmpleado;
        this.departemento = departemento;
        this.salario = salario;
    }

    public Persona getDatosPersonales() {
        return datosPersonales;
    }

    public void setDatosPersonales(Persona datosPersonales) {
        this.datosPersonales = datosPersonales;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getDepartemento() {
        return departemento;
    }

    public void setDepartemento(String departemento) {
        this.departemento = departemento;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    


}
