package Colas;

import Datos.Vacaciones;
import Listas.ListaEmpleados;
import Listas.NodoEmpleado;

public class NodoColaVa {

    private NodoColaVa siguiente;
    private Vacaciones dato;
    private NodoEmpleado empleado;

    public NodoColaVa() {
        this.siguiente = null;
    }

    public NodoColaVa getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoColaVa siguiente) {
        this.siguiente = siguiente;
    }

    public Vacaciones getDato() {
        return dato;
    }

    public void setDato(Vacaciones dato) {
        this.dato = dato;
    }

    public NodoEmpleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(NodoEmpleado empleado) {
        this.empleado = empleado;
    }

  


   
}
