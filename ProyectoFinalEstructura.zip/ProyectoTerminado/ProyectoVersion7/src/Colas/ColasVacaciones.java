/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Colas;

import Datos.Empleado;
import Datos.Vacaciones;
import Listas.ListaEmpleados;
import Listas.NodoEmpleado;
import javax.swing.JOptionPane;

import javax.swing.JOptionPane;
//FIFO
public class ColasVacaciones {

    private NodoColaVa inicio;
    private NodoColaVa fin;

    public ColasVacaciones() {
        this.inicio = null;
        this.fin = null;
    }

    public boolean vacia() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

    public void encolarVa(int idEmpleado, ListaEmpleados listaEmpleados) {
        if (listaEmpleados.vacia()) {
            JOptionPane.showMessageDialog(null, "No hay empleados en la lista.");
            return;
        }

        NodoEmpleado aux = listaEmpleados.getInicio();
        boolean encontrado = false;
        while (aux != null) {
            if (aux.getDato().getIdEmpleado() == idEmpleado) {
                String fechaInicio = JOptionPane.showInputDialog("Ingrese la fecha de inicio de las vacaciones : ");
                String fechaFin = JOptionPane.showInputDialog("Ingrese la fecha de fin de las vacaciones : ");

            
                Vacaciones vacaciones = new Vacaciones(fechaInicio, fechaFin);

                NodoColaVa nuevoNodo = new NodoColaVa();
                nuevoNodo.setDato(vacaciones);
                nuevoNodo.setEmpleado(aux);  

                if (vacia()) {
                    inicio = nuevoNodo;
                    fin = nuevoNodo;
                } else {
                    fin.setSiguiente(nuevoNodo);
                    fin = nuevoNodo;
                }

                encontrado = true;
                break;
            }
            aux = aux.getSiguiente();
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "Nose encontro el id: " + idEmpleado );
        }
    }

    public void mostrar() {
        if (!vacia()) {
            String s = "";
            NodoColaVa aux = inicio;
            int contador = 1;
            
            while (aux != null) {
                s += "Solicitud #" + contador + "\nNombre: "
                        + aux.getEmpleado().getDato().getDatosPersonales().getNombre() + "\nId: "
                        + aux.getEmpleado().getDato().getIdEmpleado()
                        + "\nFecha de inicio:" + aux.getDato().getFechaInicio()
                        + "\nFecha final: " + aux.getDato().getFechaFin() + "\n \n";

                aux = aux.getSiguiente();
                contador++;
            }
            JOptionPane.showMessageDialog(null, "Solicitudes de vacaciones:\n" + s + "\n\n");
        } else {
            JOptionPane.showMessageDialog(null, "No hay solicitudes de vacaciones.");
        }
    }

    public void desencolarVacaciones() {
        if (!vacia()) {
            JOptionPane.showMessageDialog(null, "solicitud de vacaciones eliminada.");
            JOptionPane.showMessageDialog(null, "Fecha de inicio: " + inicio.getDato().getFechaInicio()
            + "\nFecha de fin: " + inicio.getDato().getFechaFin());
            inicio = inicio.getSiguiente();

        } else {
            JOptionPane.showMessageDialog(null, "No hay vacaciones agendadadas.");
        }

    }
}









// el proximo elemento pasa a ser el primero mostrar.















































