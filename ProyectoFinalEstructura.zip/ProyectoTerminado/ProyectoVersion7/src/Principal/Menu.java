/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal;

import Colas.ColasVacaciones;
import Datos.Empleado;
import Datos.Persona;
import Listas.ListaEmpleados;
import Listas.ListaTurnoCir;
import Listas.NodoEmpleado;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import javax.swing.JOptionPane;

public class Menu {

    int op;
    ListaEmpleados l = new ListaEmpleados();
    ColasVacaciones c = new ColasVacaciones();
    ListaTurnoCir lc = new ListaTurnoCir();

    ImageIcon icono = new ImageIcon("C:\\Users\\Gateway\\Desktop\\ProyectoEstructura-20240327T171510Z-001\\ProyectoEstructura\\ProyectoV5\\ProyectoEstructuraV1\\src\\Imagenes\\inicio.png");

    public void mostrarMenu() {
        String[] menu = {
            "Gestionar Empleados\n",
            "Gestionar Vacaciones\n",
            "Gestionar Horarios\n",
            "Salir"};

        op = JOptionPane.showOptionDialog(null, "Escoja una opcion", "Sistema de Gestion", JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE, icono, menu, menu[0]
        );

        switch (op) {
            case 0:
                gestionarEmpleados();
                break;
            case 1:
                gestionarVacaciones();
                break;
            case 2:
                turnos();
                break;
            case 3:
                JOptionPane.showMessageDialog(null, "Saliendo del programa....");
                System.exit(0);
            default:
                JOptionPane.showMessageDialog(null, "Opción invalida");
                mostrarMenu();
        }
    }

    private void gestionarEmpleados() {
        String[] opciones = {"Agregar Empleado", "Eliminar Empleado", "Mostrar Lista de Empleados", "Actualizar Empleado", "Volver al Menú Principal"};

        op = JOptionPane.showOptionDialog(null,"Menu empleados", "Gestión de Empleados", JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);

        switch (op) {
            case 0:
                l.agregar();
                gestionarEmpleados();
                break;
            case 1:
                l.eliminar();
                gestionarEmpleados();
                break;
            case 2:
                l.mostrar();
                gestionarEmpleados();
                break;
            case 3:
                l.modificar();
                gestionarEmpleados();
                break;
            case 4:
                mostrarMenu();
                break;
            default:
                JOptionPane.showMessageDialog(null, "Opción no válida. intente de nuevo.");
                gestionarEmpleados();
        }
    }

    private void gestionarVacaciones() {
        String[] menuVacaciones = {
                 "1. Asignar Vacaciones\n"
                , "2. Eliminar Vacaciones\n"
                , "3. Mostrar Vacaciones\n"
                , "4. Volver al Menu Principal"};
        int op = JOptionPane.showOptionDialog(null, "Gestion Vacaciones", "Vacaciones", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, menuVacaciones, menuVacaciones[0]);
        switch (op) {
            case 0:
                c.encolarVa(Integer.parseInt(JOptionPane.showInputDialog("Digite el ID del empleado: ")), l);
                gestionarVacaciones();
                break;
            case 1:
                c.desencolarVacaciones();
                gestionarVacaciones();
                break;
            case 2:
                c.mostrar();
                gestionarVacaciones();
                break;
            case 3:
                mostrarMenu();
                break;
            default:
                JOptionPane.showMessageDialog(null, "Opción no válida. intente de nuevo.");
                gestionarVacaciones();
        }
    }

    private void turnos() {
        String[] menuTurnos ={
                 "1. Asignar Turnos\n"
                , "2. Eliminar Turnos\n"
                , "3. Mostrar Turnos\n"
                , "4. Modificar Turnos.\n"
                , "5. Volver al menu Principal"};
        int op = JOptionPane.showOptionDialog(null, "Gestion Turnos", "Turnos", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, menuTurnos, menuTurnos[0]);

        switch (op) {
            case 0:
                lc.agregarTurno(Integer.parseInt(JOptionPane.showInputDialog("Dijite el ID del Empleado: ")), l);
                turnos();
                break;
            case 1:
                lc.extraer();
                turnos();
                break;
            case 2:
                lc.mostrar();
                turnos();
                break;
            case 3:
                lc.modificarTurnos(Integer.parseInt(JOptionPane.showInputDialog("Dijite el id del empleado: ")), l);
                turnos();
                
                break;

            case 4:
                mostrarMenu();
            default:
                JOptionPane.showMessageDialog(null, "Opción no válida. intente de nuevo.");
                gestionarVacaciones();
        }
    }

}
