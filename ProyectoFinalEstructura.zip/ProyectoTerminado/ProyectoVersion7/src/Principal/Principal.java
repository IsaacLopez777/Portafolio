/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Principal;

import Colas.ColasVacaciones;
import Datos.Empleado;
import Datos.Persona;
import Listas.ListaEmpleados;
import Listas.ListaTurnoCir;
import javax.swing.JOptionPane;

/**
 *
 * @author lopez
 */
public class Principal {

    public static void main(String[] args) {
        
        Menu m = new Menu();
        m.mostrarMenu();
        
        
    }

}
